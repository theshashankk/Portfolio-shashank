# My Portfolio Site

Welcome to the repository for my personal portfolio website!

This site is built to showcase my projects, skills, and provide a way for visitors to learn more about me and get in touch.

## Features

-   **Project Showcase:** Dedicated section to highlight key projects with details.
-   **About Me:** Information about my background, skills, and interests.
-   **Contact Form:** Easy way for visitors to send me a message.
-   **Responsive Design:** Optimized for various devices and screen sizes.
-   **Theme Toggle:** Allows users to switch between light and dark modes.

## Technologies Used

-   [Next.js](https://nextjs.org/) (React Framework)
-   [React](https://reactjs.org/)
-   [TypeScript](https://www.typescriptlang.org/)
-   [Tailwind CSS](https://tailwindcss.com/)
-   [GSAP](https://gsap.com/) (for animations)
-   [React Icons](https://react-icons.github.io/react-icons/)

## Contact

If you have any questions or just want to connect, feel free to reach out:

-   [Portfolio Site](https://xditya.me)
-   [LinkedIn](https://linkedin.com/in/xditya/)
-   [GitHub](https://github.com/xditya)
-   [Telegram](https://t.me/xditya)

Thank you for checking out my portfolio!
